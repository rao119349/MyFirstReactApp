const Blog = () => {
return(
    <>
    <h1>Welcome It&#180;s a Blog page </h1>
    <p>Write Your Blogs Here</p>
    </>
)
}

export default Blog
