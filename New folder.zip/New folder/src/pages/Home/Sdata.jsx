// import myData from "https://data.covid19india.org/data.json";

// console.log (myData);

const Sdata = [
{
    imagesrc: "https://wallpapercave.com/wp/wp10441066.jpg",
    stitle: "The Dark Knight",
    summary: "After Gordon, Dent and Batman begin an assault on Gotham's organised crime, the mobs hire.",
    link: "https://www.codeply.com/p/Pk8EJO612B"
},
{
    imagesrc: "https://wallpapercave.com/wp/wp4651134.jpg",
    stitle: "Terminator : Dark Fate",
    summary: "Some quick example text to build on the card title and make up the bulk of the card's content.",
    link: "https://www.amazon.com/Terminator-Dark-Fate-Linda-Hamilton/dp/B07ZP6Y75T"
},
{
    imagesrc: "https://img.onmanorama.com/content/dam/mm/en/entertainment/entertainment-news/images/2021/7/16/shershah-movie.jpg",
    stitle: "SherShah",
    summary: "The story of PVC awardee Indian soldier Capt. Vikram Batra, who shot to fame during Kargil War.",
    link: "https://codepen.io/KryptoniteDove/post/load-json-file-locally-using-pure-javascript"
},
{
    imagesrc: "https://m.media-amazon.com/images/M/MV5BMjE0Nzg2MzI3MF5BMl5BanBnXkFtZTYwMjExODQ3._V1_FMjpg_UX1000_.jpg",
    stitle: "Blade Trinity",
    summary: "Blade, now a wanted man by the FBI, must join forces with the Nightstalkers to face : Dracula.",
    link: "https://www.imdb.com/title/tt0359013/"
},
{
    imagesrc: "https://wallpapercave.com/uwp/uwp2661268.jpeg",
    stitle: "Ice Age 3",
    summary: "Ice Age is a 2002 American computer-animated adventure comedy film Studios.",
    link: "https://data.covid19india.org/data.json"
},
{
    imagesrc: "https://wallpapercave.com/uwp/uwp1832300.jpeg",
    stitle: "PokeMon",
    summary: "Pokémon is a Japanese media franchise managed by The Pokémon Company.",
    link: "https://www.delftstack.com/howto/javascript/get-json-from-url-in-javascript/#:~:text=getJSON(url%2C%20data%2C%20success,status%20comes%20through%20the%20success%20."
},
{
    imagesrc: "https://wallpapercave.com/dwp1x/wp2765115.jpg",
    stitle: "Mahabharata",
    summary: "The Mahābhārata is one of the two major Sanskrit epics of ancient India.",
    link: "_blank"
},
{
    imagesrc: "https://wallpapercave.com/dwp1x/wp3268662.jpg",
    stitle: "Porsche Cayne",
    summary: "Porsche 718 Cayman is the petrol variant in the Porsche 718 lineup and is priced at ₹ 1.32 Crore.",
    link: "_blank"
}
];




export default Sdata;