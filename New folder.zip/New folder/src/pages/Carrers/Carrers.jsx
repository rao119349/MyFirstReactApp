const Carrers = () => {

    return(
        <>
        <h1>You want to Join Us!</h1>
        <p>Connect with us if you are ready to push your limits.</p>
        </>
    )

}

export default Carrers