import React from 'react'

const Teams = () => {
  return (
    <>
    <h1>That&#180;s Our Creative Team</h1>
    <p>Connect with Supermans & Ms. Marvels here.</p>
    </>
  )
}

export default Teams