import React from 'react'

const Contact = () => {
  return (
    <>
<h1>You are on Contact Page Now!</h1>
    <p>Write down your contacts here.</p>
</>
  )
}

export default Contact